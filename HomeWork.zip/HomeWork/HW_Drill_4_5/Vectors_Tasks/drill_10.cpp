#include <iostream>
#include <vector>

using namespace std;

int main(){
	vector <int> num;
	cout<<"Enter some integeral Values."<<endl;
	for(int n; cin>>n;){
		num.push_back(n);
	}
	cout<<"\nResults of entersed values.\n"<<endl;
	
	for(int i=0; i<num.size(); i++){
		cout<<"num["<<i<<"]"<<" = "<<num[i]<<" meters."<<endl;
	}

	return 0;
	
}
