#include <iostream>
using namespace std;

int main(){
	double num1, num2;
	string str;
	while(str != "|"){
		cout<<"Enter Two Numbers Sperating them by 'space' or 'enter' : ";
		cin>>num1>>num2;
		if(num1>num2){
			cout<<"the Larger value is: "<<num1<<endl;
			cout<<"the Smaller value is: "<<num2<<endl;
		}
		else if(num1<num2){
			cout<<"the Larger value is: "<<num2<<endl;
			cout<<"the Smaller value is: "<<num1<<endl;
		}
		else{
			cout<<"Both are equal...."<<endl;
		}
		cout<<"\nThe Numbers you Enter are "<<num1<<" & "<<num2<<"\n\nFor terminating loop Enter '|', and for countinue Enter any Key :"<<endl;
		cin>>str;
	}
	
}
