#include <iostream>
#include <math.h>

using namespace std;

int main(){
	double min = LONG_MAX, max = LONG_MIN, num;
	string unit;
	cout<<"Enter some double Numbers with units (m, cm, in,ft), \nNOTE: No unit OR ilegal units are not allowed \n\nEnter a Number : ";
	while(cin>>num){
		cout<<"Enter Unit (e.g: m, cm, in,ft) : ";
		cin>>unit;
		if(unit == "" || unit == "y" || unit == "yard" || unit == "km" || unit == "meter" || unit == "gallons"){
			cout<<"Error:  YOU ENTERED AN ILLEGAL UNIT, TRY AGAIN"<<endl;
		}
		else{
			if(unit == "m")
				cout<<"Entered Value is : "<<num<<"m"<<endl;
			else if(unit == "cm")
				cout<<"Entered Value is : "<<num<<"cm"<<endl;
			else if(unit == "in")
				cout<<"Entered Value is : "<<num<<"in"<<endl;
			else if(unit == "ft")
				cout<<"Entered Value is : "<<num<<"ft"<<endl;
			else{
				cout<<"Error:  YOU ENTERED AN ILLEGAL UNIT, TRY AGAIN"<<endl;
			}
	}
		cout<<"Enter an Other Number with unit: ";
}

	return 0;
	
}
