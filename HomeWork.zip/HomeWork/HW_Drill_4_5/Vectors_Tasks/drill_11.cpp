#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main(){
	vector <int> num;
	cout<<"Enter some integeral Values."<<endl;
	for(int n; cin>>n;){
		num.push_back(n);
	}
	cout<<"\nResults of entersed values after SORTING.\n"<<endl;
	
	int temp;
	
	    for(int i=0; i<(num.size()-1); i++)
    {
        for(int j=0; j<(num.size()-i-1); j++)
        {
            if(num[j]>num[j+1])
            {
                temp = num[j];
                num[j] = num[j+1];
                num[j+1] = temp;
            }
        }
    }
	
	
	for(int i=0; i<num.size(); i++){
		cout<<"num["<<i<<"]"<<" = "<<num[i]<<" meters."<<endl;
	}

	return 0;
	
}
