#include <iostream>
#include <math.h>

using namespace std;

int main(){
	double min = LONG_MAX, max = LONG_MIN, num;
	cout<<"Enter some double Numbers Sperating them by 'space' or 'enter' : ";
	while(cin>>num){
		if(max<= num)
			max = num;
		else if(min>=num)
			min = num;
		cout<<"Enter an Other Number : ";
		
}
cout<<"\n\n Maximum Number so far : "<<max;
cout<<"\n\n Mimimum Number so far : "<<min<<endl;

	return 0;
	
}
