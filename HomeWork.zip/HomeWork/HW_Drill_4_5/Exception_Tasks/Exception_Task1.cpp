#include <iostream>

using namespace std;
int main(){
try {
  //Cout << "Success!\n";     // syntax error.
  cout << "Success!\n";
 //keep_window_open(s);
 return 0;
}

catch (exception& e) {
 cerr << "error: " << e.what() << '\n'; 
 //keep_window_open();
 return 1;
}
catch (...){
 cerr << "Oops: unknown exception!\n"; 
 //keep_window_open();
 return 2;
}

}
