#include <iostream>
using namespace std;

class Token { // a very simple user-defined type
public:
 char kind;
 double value;
};

int main()
{
	Token op; 			   // t is a Token
	op.kind = '+'; 		  // t represents a +
	Token val; 			 // t2 is another Token
	val.kind = '8'; 		// we use the digit 8 as the �kind� for numbers
	val.value = 3.14;
	//Token op {'+'}; // initialize t1 so that t1.kind = �+�
	//Token val {'8',11.5}; // initialize t2 so that t2.kind = �8� and t2.value = 11.5

	Token newOp = op;	   // copy initialization
	op = val; 		  // assignment
	cout << op.value; // will print 3.14
}
