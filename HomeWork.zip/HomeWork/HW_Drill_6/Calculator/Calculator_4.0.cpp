#include "std_lib_facilities.h"
using namespace std;

double expression();        //prototype of experssion function.
double term();             //prototype of term function.
double primary();         //prototype of primary function.

class Token {           // a very simple user-defined type
public:
    char kind;
    double value;
};

int main(){

    try {
        double val = 0;
        while (cin) {
            Token t = ts.get();
            if (t.kind == 'q') break;    // ‘q’ for “quit”
            if (t.kind == ';')          // ‘;’ for “print now”
                cout << " = " << val << '\n';
            else
                ts.putback(t);
                val = expression();
        }
        return 0;
    }
    catch (exception& e) {
        cerr << e.what() << '\n';
        keep_window_open ();
        return 1;
    }
    catch (...) {
        cerr<<"exception \n";
        keep_window_open ();
        return 2;
    }

}

double expression()
{
    double left = term();       // read and evaluate a Term
    Token t = ts.get();        // get the next Token from the Token stream
    while (true) {
        switch (t.kind) {
            case '+':
                left += term();         // evaluate Term and add
                t = ts.get();
                break;
            case '-':
                left -= term();     // evaluate Term and subtract
                t = ts.get();
                break;
            default: 
                ts.putback(t);  // put t back into the token stream
                return left;   // finally: no more + or –; return the answer
        }
    }
}

double term(){

    double left = primary();
    Token t = ts.get();        // get the next Token from the Token stream
    while (true) {
        switch (t.kind) {
            case '*':
                left *= primary();
                t = ts.get();
                break;
            case '/':
            {
                double d = primary();
                if (d == 0) error("divide by zero");
                left /= d; 
                t = ts.get();
                break;
            }
            /*case '%':    //becouse % don't work with floating point values.
                left %= primary();
                t = ts.get();
                break;             */ 
            default: 
                ts.putback(t); // put t back into the Token stream
                return left;
        }
    }
}

double primary(){

    Token t = ts.get();
    switch (t.kind) {
        case '(':                     // handle ‘(‘ expression ‘)’
        {
            double d = expression();
            t = ts.get();
            if ( t.kind != ')' ) error(" ')' expected ");
            return d;
        }
        case '8':               // we use ‘8’ to represent a number
            return t.value;    // return the number’s value
        default:
            error("primary expected");
            ts.putback(t);
    }
}